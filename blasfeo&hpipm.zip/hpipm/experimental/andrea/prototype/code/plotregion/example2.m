
close all

plotregion([1 1],[0.6],[0 0],[1 1],'m',0.3,4*(rand(2,7)-0.5),'r:','gxbx');

axis equal
